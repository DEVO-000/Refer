# -*- coding: utf-8 -*-
"""metrics — аналитика генераций (LLM-вызовы, подгонка страниц, итоги работ).

Пишет JSONL и умеет считать сводку: успешность моделей, среднее число
итераций подгонки, точность попадания в страницы.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field, asdict


_METRICS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "metrics.jsonl")
_MAX_BYTES = 10 * 1024 * 1024


@dataclass
class GenerationMetrics:
    """Одно событие аналитики. Все поля опциональны, кроме event."""
    event: str = "generic"                # llm_call | work | image_search | ...
    model_key: str | None = None
    provider: str | None = None
    success: bool | None = None
    duration_seconds: float | None = None
    note: str = ""
    doc_type: str | None = None
    topic: str | None = None
    pages: int | None = None
    final_pages: int | None = None
    iterations: int | None = None
    user_id: int | None = None
    ts: float = field(default_factory=time.time)


class Metrics:
    def __init__(self, path: str = _METRICS_FILE) -> None:
        self.path = path

    def _rotate_if_needed(self) -> None:
        """Усечение лога до последней половины без загрузки всего файла в RAM."""
        try:
            if not (os.path.exists(self.path) and os.path.getsize(self.path) > _MAX_BYTES):
                return
            size = os.path.getsize(self.path)
            keep_from = size // 2
            tmp = self.path + ".rot.tmp"
            with open(self.path, "rb") as src, open(tmp, "wb") as dst:
                src.seek(keep_from)
                src.readline()  # отбрасываем обрезанную первую строку
                while True:
                    chunk = src.read(1024 * 1024)
                    if not chunk:
                        break
                    dst.write(chunk)
            os.replace(tmp, self.path)
        except Exception:
            try:
                if os.path.exists(self.path + ".rot.tmp"):
                    os.remove(self.path + ".rot.tmp")
            except Exception:
                pass

    def log(self, m: GenerationMetrics) -> None:
        try:
            self._rotate_if_needed()
            record = {k: v for k, v in asdict(m).items() if v is not None and v != ""}
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            pass  # аналитика никогда не ломает генерацию

    def summary(self, days: int = 7) -> dict:
        cutoff = time.time() - days * 86400
        total = ok = 0
        page_hits = page_events = 0
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        r = json.loads(line)
                    except Exception:
                        continue
                    if float(r.get("ts", 0)) < cutoff:
                        continue
                    total += 1
                    if r.get("success"):
                        ok += 1
                    if r.get("event") == "work" and r.get("pages") and r.get("final_pages"):
                        page_events += 1
                        if abs(int(r["final_pages"]) - int(r["pages"])) <= 1:
                            page_hits += 1
        except FileNotFoundError:
            pass
        except Exception:
            pass
        return {
            "total": total,
            "success": ok,
            "page_accuracy": (page_hits / page_events) if page_events else None,
        }


_metrics_singleton: Metrics | None = None


def get_metrics() -> Metrics:
    global _metrics_singleton
    if _metrics_singleton is None:
        _metrics_singleton = Metrics()
    return _metrics_singleton

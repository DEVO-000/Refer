# -*- coding: utf-8 -*-
"""Тесты провайдера КиберЛенинки в sources_real (итерация 6).

Все данные — моки, сеть не нужна. Проверяем три вещи:
  1. парсер поиска достаёт только настоящие статьи;
  2. метаданные собираются СТРОГО из citation_* страницы статьи;
  3. при любой ошибке возвращается пустой список — выдумок нет.
Запуск: python3 test_cyberleninka.py
"""
import asyncio
import sys

import sources_real as SR

FAILED = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   " + name)
    else:
        print("  FAIL " + name + "  " + str(detail))
        FAILED.append(name)


# ── 1. Разбор карточки поиска ────────────────────────────────────────
print("1. Разбор карточки /api/search")
item = {
    "name": "<b>ЦИФРОВАЯ</b> <b>ЭКОНОМИКА</b>",
    "annotation": "В статье рассматривается цифровая экономика.",
    "link": "/article/n/tsifrovaya-ekonomika-2",
    "authors": ["Аллеков А. Б.", "Гурбанов Д. А."],
    "year": 2023,
    "journal": "Символ науки",
    "journal_link": "/journal/n/simvol-nauki",
}
rec = SR._parse_cyberleninka_item(item)
check("карточка распознана", rec is not None)
check("подсветка <b> снята", rec.title == "ЦИФРОВАЯ ЭКОНОМИКА", rec.title)
check("авторы на месте", rec.authors == ["Аллеков А. Б.", "Гурбанов Д. А."], rec.authors)
check("год", rec.year == "2023", rec.year)
check("журнал", rec.container == "Символ науки", rec.container)
check("полный URL статьи", rec.url == "https://cyberleninka.ru/article/n/tsifrovaya-ekonomika-2", rec.url)
check("origin=cyberleninka", rec.origin == "cyberleninka")

print("\n2. Отбраковка мусорных карточек")
check("ссылка не на статью → None", SR._parse_cyberleninka_item({**item, "link": "/journal/n/x"}) is None)
check("короткое название → None", SR._parse_cyberleninka_item({**item, "name": "Коротко"}) is None)
check("не словарь → None", SR._parse_cyberleninka_item("мусор") is None)
check("без ссылки → None", SR._parse_cyberleninka_item({"name": "Какое-то длинное название"}) is None)
bad_year = SR._parse_cyberleninka_item({**item, "year": "недатированный"})
check("мусорный год отброшен", bad_year is not None and bad_year.year == "", bad_year and bad_year.year)

# ── 3. Метаданные страницы статьи ────────────────────────────────────
print("\n3. Страница статьи: только реальные citation_* метатеги")
ARTICLE_HTML = """
<html><head>
<meta name="citation_title" content="Цифровая экономика региона"/>
<meta name="citation_author" content="Батракова Л. Г."/>
<meta name="citation_publication_date" content="2019"/>
<meta name="citation_journal_title" content="Социально-политические исследования"/>
<meta name="citation_issue" content="1"/>
<meta name="citation_firstpage" content="12"/>
<meta name="citation_lastpage" content="19"/>
<meta name="citation_issn" content="2410-700X"/>
</head><body>текст</body></html>
"""
rec2 = SR._record_from_article_page(ARTICLE_HTML, "https://cyberleninka.ru/article/n/x")
check("запись построена", rec2 is not None)
check("название из метатега", rec2.title == "Цифровая экономика региона", rec2.title)
check("автор из метатега", rec2.authors == ["Батракова Л. Г."], rec2.authors)
check("год из метатега", rec2.year == "2019", rec2.year)
check("журнал из метатега", rec2.container == "Социально-политические исследования", rec2.container)
check("номер выпуска", rec2.issue == "1", rec2.issue)
check("диапазон страниц", rec2.pages == "12-19", rec2.pages)
check("пометка verified=True (страница загружена)", rec2.verified is True)

print("\n4. ГОСТ-оформление записи КиберЛенинки")
gost = SR.format_gost(rec2)
check("фамилия в заголовке", gost.startswith("Батракова Л. Г."), gost)
check("сведения после косой черты (инициалы перед фамилией)", "/ Л. Г. Батракова" in gost, gost)
check("журнал через тире", "— Социально-политические исследования" in gost, gost)
check("страницы через С.", "— С. 12–19" in gost, gost)
check("URL на месте", rec2.url in gost, gost)
check("нет склеенных инициалов", "Батракова Л.Г." not in gost, gost)

# Склеенные инициалы «А.Б.» не теряют вторую букву (регрессия v6)
print("\n5. Склеенные инициалы не теряются")
rec3 = SR._record_from_article_page(
    ARTICLE_HTML.replace("Батракова Л. Г.", "Аллеков А.Б."),
    "https://cyberleninka.ru/article/n/x",
)
check("«А.Б.» → «А. Б.»", "Аллеков А. Б." in SR.format_gost(rec3), SR.format_gost(rec3))

# ── 6. Сбои сети/разметки → пустой список, БЕЗ выдумок ──────────────
print("\n6. Сбои → пустой список (ничего не фабрикуется)")


class _FakeBody:
    """Имитация resp.content.read(limit) из aiohttp."""

    def __init__(self, body: bytes):
        self._body = body

    async def read(self, limit: int = -1) -> bytes:
        return self._body if limit < 0 else self._body[:limit]


class _FakeResp:
    def __init__(self, status=200, body=b""):
        self.status = status
        self._body = body
        self.content = _FakeBody(body)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def text(self):
        return self._body.decode("utf-8", "ignore")

    async def json(self):
        import json as _j
        return _j.loads(self._body)


class _FakeSession:
    """Мок aiohttp.ClientSession: управляется сценарием."""

    def __init__(self, post_body=None, post_status=200, get_status=200, get_body=b""):
        self._post_body = post_body
        self._post_status = post_status
        self._get_status = get_status
        self._get_body = get_body

    def post(self, url, json=None, headers=None, timeout=None):
        return _FakeResp(self._post_status, self._post_body)

    def get(self, url, headers=None, timeout=None, allow_redirects=True):
        return _FakeResp(self._get_status, self._get_body)


API_RESPONSE = b'{"found": 1, "articles": [' + str(item).replace("'", '"').encode() + b']}'
ok_session = _FakeSession(post_body=API_RESPONSE, get_body=ARTICLE_HTML.encode())
recs = asyncio.run(SR.search_cyberleninka(ok_session, "тест", limit=3))
check("happy path: 1 статья", len(recs) == 1, [r.title for r in recs])
check("happy path: данные со страницы", recs and recs[0].title == "Цифровая экономика региона")

dead_sessions = [
    ("API вернул 500", _FakeSession(post_status=500)),
    ("API вернул мусор", _FakeSession(post_body="<html>не json</html>".encode())),
    ("API вернул пусто", _FakeSession(post_body=b'{"found": 0, "articles": []}')),
    ("API вернул None-формат", _FakeSession(post_body='{"articles": "не список"}'.encode())),
    ("страница статьи 404", _FakeSession(post_body=API_RESPONSE, get_status=404)),
]
for name, sess in dead_sessions:
    got = asyncio.run(SR.search_cyberleninka(sess, "тест", limit=3))
    check(name + " → []", got == [], got)

# Страница 404, но карточка поиска валидна: запись НЕ должна просочиться
# с verified=True — по коду 404-страница отбраковывает запись целиком.
got = asyncio.run(SR.search_cyberleninka(dead_sessions[4][1], "тест", limit=3))
check("404 страницы → запись отброшена", got == [], got)

# ── 7. Валидация записи против заглушек ─────────────────────────────
print("\n7. Общая защита от заглушек действует и на КиберЛенинку")
stub = SR._parse_cyberleninka_item({**item, "name": "Материал с сайта по теме исследования"})
check("заглушка-название отброшена", stub is None)

print("\n" + "=" * 62)
if FAILED:
    print("FAILED: " + str(len(FAILED)) + " -> " + str(FAILED))
    sys.exit(1)
print("ALL TESTS PASSED")
